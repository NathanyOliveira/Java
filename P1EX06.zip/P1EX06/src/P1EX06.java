
public class P1EX06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double raio = 5;
		double per = 2 * 3.14159;
		double area = 3.14159 * (raio * raio);
		
		System.out.println("O per�metro � igual a "+per);
		System.out.println("A �rea " +area+ " de um c�rculo com o raio igual a " +raio+ "cm � igual a "+per);
		

	}

}
