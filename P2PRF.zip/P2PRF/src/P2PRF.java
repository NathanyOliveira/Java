import java.util.Scanner;

public class P2PRF {

	public static void main(String[] args) {
		// Scanner
		Scanner in = new Scanner(System.in);		
		
		// Criando os objetos
		Calculadora C1 = new Calculadora();
				
				
		System.out.println("=*=*=*=*=*=*=*==*=*=*=*=*=*=*=");
		System.out.println("        CALCULADORA			  ");
		System.out.println("=*=*=*=*=*=*=*==*=*=*=*=*=*=*=\n");
				
		System.out.println("Informe o 1� valor: ");
		C1.setN1(in.nextDouble());
				
		System.out.println("Informe o 2� valor: ");
		C1.setN2(in.nextDouble());
		
		System.out.println("Informe a opera��o escolhida de acordo com as op��es abaixo:\n\n"
				+ "1- Somar\n"
				+ "2- Subtrair\n"
				+ "3- Multiplicar\n"
				+ "4- Dividir\n\n"
				+ "A opera��o escolhida foi: ");
		C1.setOp(in.nextInt());
		
				
		switch(C1.getOp()){
		case 1:
			System.out.println("\nA soma de " + C1.getN1() + " + " + C1.getN2() + " = " + C1.setSomar());
			break;
		case 2:
			System.out.println("\nA soma de " + C1.getN1() + " - " + C1.getN2() + " = " + C1.setSubtrair());
			break;
		case 3:
			System.out.println("\nA soma de " + C1.getN1() + " * " + C1.getN2() + " = " + C1.setMultiplicar());
			break;
		case 4:
			System.out.println("\nA soma de " + C1.getN1() + " / " + C1.getN2() + " = " + C1.setDividir());
			break;
		default:
			System.out.println("\nInforme a opera��o com os n�meros de 1 a 4.");
		}
		
		
	}

}
