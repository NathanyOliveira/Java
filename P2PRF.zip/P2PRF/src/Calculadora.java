
public class Calculadora {
	
	// atributos
	public double n1;
	public double n2;
	public int op = 0;
	
	// construtores
	public Calculadora() {
		
	}
	
	public Calculadora(double n1, double n2, int op) {
		this.n1 = n1;
		this.n2 = n2;
		this.op = op;
	}

	
	// getters e setters
	public double getN1() {
		return n1;
	}

	public double getN2() {
		return n2;
	}

	public int getOp() {
		return op;
	}

	public void setN1(double n1) {
		this.n1 = n1;
	}

	public void setN2(double n2) {
		this.n2 = n2;
	}

	public void setOp(int op) {
		this.op = op;
	}
	
	// m�todos
	
	public double setSomar() {
		return (this.n1 + this.n2);
	}

	public double setSubtrair() {
		return (this.n1 - this.n2);
	}
	
	public double setMultiplicar() {
		return (this.n1 * this.n2);
	}
	
	public double setDividir() {
		return (this.n1 / this.n2);
	}	
	

	
}
	
	