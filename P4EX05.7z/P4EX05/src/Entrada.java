import java.util.Scanner; 
public class Entrada {
   public static void main (String [] args) {
	   Scanner ze = new Scanner (System.in);
	   boolean erro = true;
	   int idade=0;
	   do {
		   try {
			   System.out.print("Digite a idade..: ");
			   idade = ze.nextInt();
			   erro = false;
		   }
		   catch(Exception e) {
			   System.out.println("Idade inv�lida, por favor tente novamente");
			   erro = true;
			   ze.nextLine();
		   }
	   } while (erro);
	   
	   System.out.print("Sua idade..: "+idade);
   }
}