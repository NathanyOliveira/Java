
public class P1EX03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double C = 36;
		double F = (C * 1.8) + 32;
		double K = C + 273.15;
		double Ra = C * 1.8 + 32 + 459.67;
		double Re = C * 0.8;
		
		System.out.println("A temperatura de "+C+"�c convertida em Fahrenheit (F), � igual a "+F+"�F.");
		System.out.println("A temperatura de "+C+"�c convertida em Kelvin (K), � igual a "+K+"�K.");
		System.out.println("A temperatura de "+C+"�c convertida em Rankine (Ra), � igual a "+Ra+"�Ra.");
		System.out.println("A temperatura de "+C+"�c convertida em R�aumur (Re), � igual a "+Re+"�Re.");
		

	}

}
